package com.med.ex03

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
